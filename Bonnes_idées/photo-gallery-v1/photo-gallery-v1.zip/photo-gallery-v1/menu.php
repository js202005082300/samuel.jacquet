<?Php

echo " <a href=gallery.php>Add Gallery</a> . <a href=upload.php>Add Image</a> .  <a href=index.php>Home</a> .  <br>";

?>